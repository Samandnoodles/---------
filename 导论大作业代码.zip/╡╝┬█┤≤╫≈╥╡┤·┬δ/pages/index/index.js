Page({
  toWiredCommunication: function() {
    wx.navigateTo({
      url: '/pages/wiredCommunication/wiredCommunication'
    })
  },

  toWirelessCommunication: function() {
    wx.navigateTo({
      url: '/pages/wirelessCommunication/wirelessCommunication'
    })
  },

  toHistory: function() {
    wx.navigateTo({
      url: '/pages/history/history'
    })
  }
})