Page({
  toIntroduction: function(event) {
    const name = event.currentTarget.dataset.name
    wx.navigateTo({
      url: `/pages/introduction/introduction?name=${name}`
    })
  },

  backToIndex: function() {
    wx.navigateBack({
      delta: 1
    })
  }
})