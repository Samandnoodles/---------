Page({
  backToPreviousPage: function() {
    wx.navigateBack({
      delta: 1
    })
  },

  backToIndex: function() {
    wx.reLaunch({
      url: '/pages/index/index'
    })
  }
})